sprintf(buffer,"C compiler          : gcc version 4.4.3 (Ubuntu 4.4.3-4ubuntu5) \n");
output_string(buffer);
sprintf(buffer,"libc                : libc-2.11.1.so\n");
output_string(buffer);
