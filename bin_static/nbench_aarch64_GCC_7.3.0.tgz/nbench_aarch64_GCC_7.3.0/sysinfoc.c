sprintf(buffer,"C compiler          : aarch64-linux-gnu-gcc\n");
output_string(buffer);
sprintf(buffer,"libc                : static\n");
output_string(buffer);
