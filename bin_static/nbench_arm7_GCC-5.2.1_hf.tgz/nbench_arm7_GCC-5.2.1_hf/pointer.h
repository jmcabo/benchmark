//#define LONG64
