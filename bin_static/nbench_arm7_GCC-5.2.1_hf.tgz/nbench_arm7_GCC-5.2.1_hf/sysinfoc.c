sprintf(buffer,"C compiler          : arm-linux-gnueabihf-gcc (gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu1))\n");
output_string(buffer);
sprintf(buffer,"libc                : static (libc-2.21.so)\n");
output_string(buffer);
